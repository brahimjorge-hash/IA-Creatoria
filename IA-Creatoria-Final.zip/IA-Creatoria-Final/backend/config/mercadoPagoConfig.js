module.exports = {
    PUBLIC_KEY: process.env.MP_PUBLIC_KEY,
    ACCESS_TOKEN: process.env.MP_ACCESS_TOKEN
};
