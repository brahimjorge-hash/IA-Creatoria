# IA-Creatoria - Render-ready package (Complete)

Package includes:
- Frontend (React minimal)
- Backend (Node/Express) with Mercado Pago sandbox integration
- Render config (render.yaml, Procfile)
- .env.example (TEST Mercado Pago keys included)
- About texts (ES/EN) and payment instructions
